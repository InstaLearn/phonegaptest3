moodle-local_vmchat
===================

Moodle - Local plugin for vmchat (footer chat)


This plugin adds a footer chat bar at your site.
Users will be able to chat with other users.

Dependencies
----------------------
Getkey local module is required to run vmchat.


Installation in Moodle
----------------------
* Unzip the zip file and place the vmchat folder in local folder of Moodle.
* Go to Site administration -> Vm chat and activate this module.



change log for version 1.2
---------------------------
* jQuery confliction resolved
* Image updated
* Spelling update

change log for version 1.2.1
---------------------------
* New setting added to resolve jQuery confliction
* file removed (include.js)
* Js file directly included in header