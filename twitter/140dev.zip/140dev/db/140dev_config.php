<?php
/**
* 140dev_config.php
* Constants for the entire 140dev Twitter framework
* You MUST modify these to match your server setup when installing the framework
* 
* Latest copy of this code: http://140dev.com/free-twitter-api-source-code-library/
* @author Adam Green <140dev@gmail.com>
* @license GNU Public License
* @version BETA 0.30
*/

// OAuth settings for connecting to the Twitter streaming API
// Fill in the values for a valid Twitter app
define('TWITTER_CONSUMER_KEY','AJk0vlZ69oNmPuL8MjVYIzekq');
define('TWITTER_CONSUMER_SECRET','NNesDHpOJoWtNQ5Qj2GNGQSF0zZjwCi3R1PYMPyfnSje2exGhV');
define('OAUTH_TOKEN','141488104-TdZGwXMgGBSHVHeLor2k6jpsii67XaGM56h5OoeA');
define('OAUTH_SECRET','8UuEj5CaQfBI2nhA4sxfgH6QF89gZJaNkQeWswSYbzNyY');

// Settings for monitor_tweets.php
define('TWEET_ERROR_INTERVAL',10);
// Fill in the email address for error messages
define('TWEET_ERROR_ADDRESS','dinesh9920@gmail.com');
?>